import random

def get_patient_data():
    return {
        "heart_rate": random.randint(60, 120),
        "temperature": round(random.uniform(36.0, 39.0), 1),
        "blood_pressure": f"{random.randint(100, 140)}/{random.randint(60, 90)}"
    }
