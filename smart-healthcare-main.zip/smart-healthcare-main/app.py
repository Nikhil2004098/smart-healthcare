from flask import Flask, render_template
from sensors.mock_data import get_patient_data

app = Flask(__name__)

@app.route('/')
def dashboard():
    data = get_patient_data()

    alert = None
    if data["heart_rate"] > 100:
        alert = "⚠️ High heart rate detected!"
    elif data["temperature"] > 38.0:
        alert = "⚠️ High body temperature detected!"
    
    return render_template(
        'index.html',
        heart_rate=data["heart_rate"],
        temperature=data["temperature"],
        blood_pressure=data["blood_pressure"],
        alert=alert
    )

if __name__ == '__main__':
    app.run(debug=True)
